"""Lets the tool be run as `python -m ldapprobe --url ... --param ...`."""
import sys
from .cli import main

if __name__ == "__main__":
    sys.exit(main())
